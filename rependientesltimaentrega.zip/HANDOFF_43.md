# Handoff — 43_TRASLAPE_IOI.ipynb

## Qué hace

Cuantifica la concordancia espaciotemporal entre TS-MULE y CONFETTI para una
instancia del conjunto de prueba. Responde: **de los timesteps que CONFETTI
modifica, qué fracción cae dentro de la ventana que TS-MULE identifica como
relevante** (recall). Se calcula también el IoU como métrica complementaria.

No hay dependencias externas fuera de numpy, pickle y matplotlib. No requiere
correr TS-MULE ni CONFETTI de nuevo — carga los resultados precomputados desde
disco.

## Inputs

Dos archivos guardados después de correr los notebooks 11–23:

```
RESULTADOS_TSMULE\_resultados_tsmule_m{id}.npz
RESULTADOS_CONFETTI\_resultados_cf_m{id}.pkl
```

Donde `id` es el índice de la instancia (ej. 39 o 62). Se cambia al inicio
de la celda 2 con `m_id = 39`.

## Cómo funciona

Construye dos máscaras binarias (T × F), con el mismo criterio que
`comparison_plots.py` para que los números sean coherentes con las figuras
del notebook 31:

- `mask_mule`: celdas que TS-MULE perturbó durante su explicación
  (`|x_perturbed - x_original| > 1e-10`)
- `mask_cf`: celdas que el mejor contrafactual de CONFETTI modifica respecto
  al original (`|x_cf - x_original| > 1e-6`)

Sobre esas máscaras calcula IoU, precisión y recall por boya y global.

## Outputs

- Tabla con IoU, precisión, recall, % activo de cada método y % de traslape
  por boya y global.
- Figura `traslape_iou.png` guardada en `RESULTADOS_COMPARACION\`: 6 subplots
  (uno por boya) con azul = solo TS-MULE, naranja = solo CONFETTI,
  verde = traslape.
- Panel comparativo m=39 vs m=62 en la última celda.

## Nota de interpretación

TS-MULE opera sobre segmentos continuos amplios (~20–40% de las celdas) y
CONFETTI hace ediciones puntuales (~10%). Esa diferencia de granularidad
limita el IoU absoluto por construcción — el recall es el número más
informativo. Una concordancia alta es favorable, pero su ausencia no implica
inconsistencia: los métodos responden preguntas distintas.
